import streamlit as st
import pandas as pd
import plotly.express as px
from utils.sentiment import get_sentiment_score
from utils.llm_summary import summarize_trends

st.set_page_config(page_title="TrendPulse", layout="wide")
st.title("📈 TrendPulse: Stock Sentiment Forecasting")
st.markdown("#### 🔎 Real-time NLP-powered insights from Twitter, Reddit & News")

ticker = st.sidebar.text_input("Stock Ticker", "TSLA")
data_source = st.sidebar.selectbox("Data Source", ["Twitter", "Reddit", "News"])
model_option = st.sidebar.radio("Sentiment Model", ["VADER", "FinBERT", "LLM Summary"])

@st.cache_data
def load_data(ticker, source):
    path = f"data/processed/{ticker}_{source}.csv"
    return pd.read_csv(path)

df = load_data(ticker, data_source)

st.subheader(f"📊 Sentiment Trend for {ticker.upper()} from {data_source}")
fig = px.line(df, x="timestamp", y="sentiment_score", color="model", title="Sentiment Over Time")
st.plotly_chart(fig, use_container_width=True)

if model_option == "LLM Summary":
    recent_text = " ".join(df['text'].tail(30))
    summary = summarize_trends(recent_text)
    st.markdown("### 🤖 LLM Summary")
    st.write(summary)

st.markdown("---")
st.markdown("💬 Powered by FinBERT • Anthropic Claude • Gemini • OpenAI GPT-4")