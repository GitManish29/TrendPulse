def summarize_trends(text_block):
    import openai
    openai.api_key = "YOUR_KEY"

    prompt = f"""
    Analyze the following stock-related posts. Summarize key sentiment shifts in 3 bullet points.
    Posts: {text_block}
    """

    completion = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5,
        max_tokens=300
    )
    return completion['choices'][0]['message']['content']